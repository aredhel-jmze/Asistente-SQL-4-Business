"""End-to-end structured assistant for Deliverable 2."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .composition import ComposedAnswer, compose_results
from .model import TextGenerator, parse_json_object, plan_prompt, report_prompt
from .sql_tools import (
    QueryExecution,
    SQLExecutionError,
    SQLValidationError,
    connect_read_only,
    execute_read_only,
    retrieve_relevant_schema,
    rows_to_json,
)


@dataclass
class AssistantResult:
    question: str
    plan: dict[str, Any]
    executions: list[QueryExecution]
    composed: ComposedAnswer
    report: str
    report_claims: list[str]
    report_fidelity: bool
    attempts: int
    schema_context: str
    errors: list[str]

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["executions"] = [
            {
                "sql": execution.sql,
                "rows": rows_to_json(execution.rows),
                "error": execution.error,
            }
            for execution in self.executions
        ]
        return result


class BusinessAssistant:
    """Plan, execute, compose and report with a bounded retry budget."""

    def __init__(self, db_path: str | Path, generator: TextGenerator, max_retries: int = 2):
        self.db_path = Path(db_path)
        self.generator = generator
        self.max_retries = max(0, max_retries)

    def answer(self, question: str) -> AssistantResult:
        schema = retrieve_relevant_schema(self.db_path, question)
        errors: list[str] = []
        last_error: str | None = None
        last_plan: dict[str, Any] | None = None

        for attempt in range(1, self.max_retries + 2):
            try:
                raw_plan = self.generator.generate(plan_prompt(schema, question, last_error))
                plan = self._validate_plan(parse_json_object(raw_plan))
                last_plan = plan
                executions, composed = self._execute_plan(plan)
                report, claims = self._generate_report(question, composed.value)
                fidelity = self._validate_report(report, composed.value)
                return AssistantResult(
                    question=question,
                    plan=plan,
                    executions=executions,
                    composed=composed,
                    report=report,
                    report_claims=claims,
                    report_fidelity=fidelity,
                    attempts=attempt,
                    schema_context=schema,
                    errors=errors,
                )
            except (ValueError, SQLValidationError, SQLExecutionError) as exc:
                plan_context = ""
                if last_plan is not None:
                    plan_context = f" Plan: {json.dumps(last_plan, ensure_ascii=False)}."
                last_error = f"{exc}.{plan_context}"
                errors.append(f"attempt_{attempt}: {last_error}")

        raise RuntimeError(
            f"The assistant failed after {self.max_retries + 1} attempts: {errors[-1]}"
        )

    @staticmethod
    def _validate_plan(plan: dict[str, Any]) -> dict[str, Any]:
        steps = plan.get("steps")
        composition = plan.get("composition")
        if not isinstance(steps, list) or not steps:
            raise ValueError("The plan must contain at least one step.")
        if not isinstance(composition, dict):
            raise ValueError("The plan must contain a composition object.")
        operation = composition.get("operation")
        allowed = {"direct", "growth_pct", "compare_equal", "share_pct", "filter_then_rank"}
        if operation not in allowed:
            raise ValueError(f"Unsupported composition operation: {operation}")
        for index, step in enumerate(steps, start=1):
            if not isinstance(step, dict) or not isinstance(step.get("sql"), str):
                raise ValueError(f"Step {index} must contain SQL text.")
        if operation == "direct" and len(steps) != 1:
            raise ValueError("A direct operation must contain one step.")
        if operation != "direct" and len(steps) < 2:
            raise ValueError(f"Operation {operation} requires multiple steps.")
        return plan

    def _execute_plan(self, plan: dict[str, Any]) -> tuple[list[QueryExecution], ComposedAnswer]:
        conn = connect_read_only(self.db_path)
        executions: list[QueryExecution] = []
        try:
            for step in plan["steps"]:
                executions.append(execute_read_only(conn, step["sql"]))
            rows = [execution.rows for execution in executions]
            try:
                composed = compose_results(plan["composition"]["operation"], rows, conn=conn)
            except ValueError as exc:
                raise ValueError(f"{exc} Result sets: {rows!r}") from exc
            return executions, composed
        finally:
            conn.close()

    def _generate_report(self, question: str, answer: Any) -> tuple[str, list[str]]:
        raw = self.generator.generate(report_prompt(question, answer))
        try:
            payload = parse_json_object(raw)
            text = payload.get("answer")
            claims = payload.get("claims", [])
            if not isinstance(text, str) or not isinstance(claims, list):
                raise ValueError("The report JSON has an invalid shape.")
            return text.strip(), [str(claim) for claim in claims]
        except ValueError:
            # The verified answer remains available even if the reporter breaks its format.
            return raw.strip(), []

    @staticmethod
    def _validate_report(report: str, answer: Any) -> bool:
        """Check answer-level values without requiring every intermediate value."""

        if not report.strip():
            return False
        required_values: list[Any] = []
        if isinstance(answer, dict) and "growth_pct" in answer:
            required_values.append(answer["growth_pct"])
        elif isinstance(answer, dict) and "share_pct" in answer:
            required_values.append(answer["share_pct"])
        elif isinstance(answer, dict) and "winner" in answer:
            required_values.append(answer["winner"])
        elif isinstance(answer, dict) and "first" in answer and "second" in answer:
            required_values.extend([answer["first"], answer["second"]])
        else:
            required_values.extend(_flatten_values(answer))

        normalized_report = report.replace(",", "")
        for value in required_values:
            if value is None:
                return False
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                rounded = f"{value:.2f}".rstrip("0").rstrip(".")
                if rounded not in normalized_report and f"{value:g}" not in normalized_report:
                    return False
            elif str(value).lower() not in report.lower():
                return False
        return True


def _flatten_values(value: Any) -> list[Any]:
    if isinstance(value, dict):
        values: list[Any] = []
        for item in value.values():
            values.extend(_flatten_values(item))
        return values
    if isinstance(value, (list, tuple)):
        values: list[Any] = []
        for item in value:
            values.extend(_flatten_values(item))
        return values
    if isinstance(value, (str, int, float)) and not isinstance(value, bool):
        return [value]
    return []


def save_trace(result: AssistantResult, path: str | Path) -> None:
    Path(path).write_text(
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
