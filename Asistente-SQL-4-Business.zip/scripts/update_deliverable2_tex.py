#!/usr/bin/env python3
"""Insert measured comparison values and a real failure into deliverable2.tex."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def percentage(records: list[dict], system: str, field: str, group: str) -> str:
    subset = [record for record in records if record["type"] == group]
    values = [record[system].get(field, False) for record in subset]
    return f"{sum(values) / len(values):.1%}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/deliverable2_comparison.json")
    parser.add_argument("--tex", default="docs/deliverable2.tex")
    args = parser.parse_args()

    results_path = Path(args.results)
    tex_path = Path(args.tex)
    records = json.loads(results_path.read_text(encoding="utf-8"))
    punctual = [record for record in records if record["type"] == "puntual"]
    combined = [record for record in records if record["type"] == "combinada"]
    failure = next(
        (record for record in records if not record.get("solution", {}).get("full_correct", False)),
        None,
    )
    if failure is None:
        failure_text = "no failure was observed in the measured set"
    else:
        solution = failure.get("solution", {})
        reason = solution.get("error") or "; ".join(solution.get("errors", [])) or "the solution failed its correctness checks"
        failure_text = f"{failure['id']}: {reason.replace('_', ' ')}"
    failure_text = failure_text.replace("%", "\\%")

    text = tex_path.read_text(encoding="utf-8")
    row = (
        "Structured solution & "
        f"{percentage(records, 'solution', 'full_correct', 'puntual')} & "
        f"{percentage(records, 'solution', 'full_correct', 'combinada')} & "
        f"{percentage(records, 'solution', 'full_correct', 'puntual')}"
    )
    global_full = sum(record.get("solution", {}).get("full_correct", False) for record in records) / len(records)
    row = row.rsplit("&", 1)[0] + f"& {global_full:.1%}"
    text = re.sub(r"Structured solution & \\texttt\{RUN\} & \\texttt\{RUN\} & \\texttt\{RUN\}", row, text)
    text = text.replace("FAILURE_CASE", failure_text)
    tex_path.write_text(text, encoding="utf-8")
    print(f"Updated {tex_path} from {results_path}.")


if __name__ == "__main__":
    main()
